<!--Blog Post-->
<div class="column blog-post">
    <div class="inner-box">
        <?php if ( has_post_thumbnail() ):?>
        <figure class="image-box"><a href="<?php echo esc_url(get_permalink(get_the_id()));?>">
        	<?php the_post_thumbnail('sorto_1170x360', array('class' => 'img-responsive'));?>
        </a><div class="date"><span class="day"><?php echo get_the_date('d');?></span><span class="month"><?php echo get_the_date('M');?></span></div></figure>
        <?php endif;?>
        <div class="post-info clearfix">
            <div class="author-info pull-left"><?php esc_html_e('By ', 'sorto');?><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) )); ?>"><?php the_author();?></a></div>
            <div class="more pull-right"><a href="<?php echo esc_url(get_permalink(get_the_id()));?>" class="read-more"><?php esc_html_e('Read More', 'sorto');?></a></div>
        </div>
        <div class="content-box">
            <div class="post-cat"><?php the_category();?></div>
            <h3><a href="<?php echo esc_url(get_permalink(get_the_id()));?>"><?php the_title();?></a></h3>
            <div class="text"><?php the_excerpt();?></div>
        </div>
    </div>
</div>