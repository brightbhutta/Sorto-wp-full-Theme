<?php
$options = _WSH()->option();
    get_header(); 
?>

<!--Page Title-->
<section class="page-title">
    <div class="auto-container text-center">
    	<h4 class="small-text"><?php esc_html_e('something is wrong', 'sorto');?></h4>
        <h2 class="page-name"><?php esc_html_e('404 Page ', 'sorto');?></h2>
        
        <!--Bread Crumb-->
        <?php echo balanceTags(sorto_get_the_breadcrumb()); ?>
    </div>
</section>

<!--Error Section-->
<section class="error-section">
    <div class="auto-container">
        <div class="error-icon"><span class="flaticon-plug"></span></div>
        <div class="extra-big"><?php esc_html_e('404 Error ', 'sorto');?></div>
        <div class="bigger-text"><?php esc_html_e('Looks like desired page is Not Available.', 'sorto');?></div>
        <div class="text-lower">
            <a href="<?php echo esc_url(home_url('/'));?>" class="theme-btn btn-style-two"><?php esc_html_e('Return Home', 'sorto');?></a>
        </div>
    </div>
</section>

<!--  Your Blog Content End Here -->  		
<?php get_footer(); ?>