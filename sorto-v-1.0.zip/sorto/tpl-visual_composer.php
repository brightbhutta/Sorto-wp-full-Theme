<?php /* Template Name: VC Page */
	get_header() ;
	$meta = _WSH()->get_meta('_bunch_header_settings');
	$bg = sorto_set($meta, 'header_img');
	$title = sorto_set($meta, 'header_title');
	$year = sorto_set($meta, 'year');
?>
<?php if(sorto_set($meta, 'breadcrumb')):?>
	
    <!--Page Title-->
    <section class="page-title">
    	<div class="auto-container text-center">
        	<h4 class="small-text"><?php if($year) echo balanceTags($year);?></h4>
            <h2 class="page-name"><?php if($title) echo balanceTags($title); else wp_title('');?></h2>
            <!--Bread Crumb-->
            <div class="bread-crumb clearfix">
			<?php echo balanceTags(sorto_get_the_breadcrumb()); ?>
            </div>
            
        </div>
    </section>
    
<?php endif;?>
<?php while( have_posts() ): the_post(); ?>
    <?php the_content(); ?>
<?php endwhile;  ?>
<?php get_footer() ; ?>