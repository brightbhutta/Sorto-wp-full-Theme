<?php $options = get_option('wp_sorto'.'_theme_options');?>
	
    <!--Main Footer-->
    <footer class="main-footer">
    	
        <!--Footer Upper-->        
        <?php if(!(sorto_set($options, 'hide_upper_footer'))):?>
        <div class="footer-upper">
            <?php if ( is_active_sidebar( 'footer-sidebar' ) ) { ?>
                <div class="auto-container">
                    <div class="row clearfix">
                        <?php dynamic_sidebar( 'footer-sidebar' ); ?>
                    </div>
                </div>
            <?php } ?>
        </div>
        <?php endif;?>
        
        <!--Footer Bottom-->
    	<?php if(!(sorto_set($options, 'hide_bottom_footer'))):?>
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="outer-box text-center">
                    
                    <!--Copyright-->
                	<div class="copyright"><?php echo balanceTags(sorto_set($options, 'copy_right'));?></div>
                    
                </div>
            </div>
        </div>
        <?php endif;?>
    </footer>
    
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon flaticon-transport-2"></span></div>

<?php wp_footer(); ?>
</body>
</html>