<!-- Search Form -->
<div class="search-box">
    <form method="get" action="<?php echo esc_url(home_url('/')); ?>">
        <div class="form-group">
            <input type="search" name="s" value="" placeholder="<?php esc_html_e('Search Here', 'sorto');?>">
            <button type="submit"><span class="icon flaticon-check"></span></button>
        </div>
    </form>
    
</div>