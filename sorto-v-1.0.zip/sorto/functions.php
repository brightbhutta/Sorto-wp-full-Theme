<?php
add_action('after_setup_theme', 'sorto_bunch_theme_setup');
function sorto_bunch_theme_setup()
{
	global $wp_version;
	if(!defined('SORTO_VERSION')) define('SORTO_VERSION', '1.0');
	if( !defined( 'SORTO_ROOT' ) ) define('SORTO_ROOT', get_template_directory().'/');
	if( !defined( 'SORTO_URL' ) ) define('SORTO_URL', get_template_directory_uri().'/');	
	include_once get_template_directory() . '/includes/loader.php';
	
	
	load_theme_textdomain('sorto', get_template_directory() . '/languages');
	
	//ADD THUMBNAIL SUPPORT
	add_theme_support('post-thumbnails');
	add_theme_support('menus'); //Add menu support
	add_theme_support('automatic-feed-links'); //Enables post and comment RSS feed links to head.
	add_theme_support('widgets'); //Add widgets and sidebar support
	add_theme_support( "title-tag" );
	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );
	/** Register wp_nav_menus */
	if(function_exists('register_nav_menu'))
	{
		register_nav_menus(
			array(
				/** Register Main Menu location header */
				'main_menu' => esc_html__('Main Menu', 'sorto'),
				'topbar_menu' => esc_html__('Topbar Menu', 'sorto'),
			)
		);
	}
	if ( ! isset( $content_width ) ) $content_width = 960;
	add_image_size( 'sorto_480x240', 480, 240, true ); // '480x240' services_gradient
	add_image_size( 'sorto_340x210', 340, 210, true ); // '340x210' portfolio_preview
	add_image_size( 'sorto_100x100', 100, 100, true ); // '100x100' testimonial_round
	add_image_size( 'sorto_370x230', 370, 230, true ); // '370x230' Our Team
	add_image_size( 'sorto_520x320', 520, 320, true ); // '520x320' why choose us
	add_image_size( 'sorto_390x200', 390, 200, true ); // '390x200' Our blog
	add_image_size( 'sorto_180x140', 180, 140, true ); // '180x140' testimonial_box
	add_image_size( 'sorto_390x300', 390, 300, true ); // '390x300' gallery Two
	add_image_size( 'sorto_1170x360', 1170, 360, true ); // '1170x360' Blog Classic
	add_image_size( 'sorto_80x80', 80, 80, true ); // '80x80' Recent News
	
	
	
}
function sorto_bunch_widget_init()
{
	global $wp_registered_sidebars;
	$theme_options = _WSH()->option();
	if( class_exists( 'Bunch_About_Author' ) )register_widget( 'Bunch_About_Author' );
	if( class_exists( 'Bunch_Recent_Post_With_Image' ) )register_widget( 'Bunch_Recent_Post_With_Image' );
	if( class_exists( 'Bunch_About_Sorto' ) )register_widget( 'Bunch_About_Sorto' );
	if( class_exists( 'Bunch_Latest_News' ) )register_widget( 'Bunch_Latest_News' );
	if( class_exists( 'Bunch_Flicker_Gallery' ) )register_widget( 'Bunch_Flicker_Gallery' );
	if( class_exists( 'Bunch_External_Links' ) )register_widget( 'Bunch_External_Links' );
	if( class_exists( 'Bunch_Contact_Info' ) )register_widget( 'Bunch_Contact_Info' );
	
	
	register_sidebar(array(
	  'name' => esc_html__( 'Default Sidebar', 'sorto' ),
	  'id' => 'default-sidebar',
	  'description' => esc_html__( 'Widgets in this area will be shown on the right-hand side.', 'sorto' ),
	  'before_widget'=>'<div id="%1$s" class="widget sidebar-widget %2$s">',
	  'after_widget'=>'</div>',
	  'before_title' => '<div class="sidebar-title"><h2>',
	  'after_title' => '</h2></div>'
	));
	register_sidebar(array(
	  'name' => esc_html__( 'Footer Sidebar', 'sorto' ),
	  'id' => 'footer-sidebar',
	  'description' => esc_html__( 'Widgets in this area will be shown in Footer Area.', 'sorto' ),
	  'before_widget'=>'<div id="%1$s"  class="col-lg-3 col-md-3 col-sm-6 col-xs-12 column footer-widget %2$s">',
	  'after_widget'=>'</div>',
	  'before_title' => '<h2>',
	  'after_title' => '</h2>'
	));
	
	register_sidebar(array(
	  'name' => esc_html__( 'Blog Listing', 'sorto' ),
	  'id' => 'blog-sidebar',
	  'description' => esc_html__( 'Widgets in this area will be shown on the right-hand side.', 'sorto' ),
	  'before_widget'=>'<div id="%1$s" class="widget sidebar-widget %2$s">',
	  'after_widget'=>'</div>',
	  'before_title' => '<div class="sidebar-title"><h2>',
	  'after_title' => '</h2></div>'
	));
	if( !is_object( _WSH() )  )  return;
	$sidebars = sorto_set(sorto_set( $theme_options, 'dynamic_sidebar' ) , 'dynamic_sidebar' ); 
	foreach( array_filter((array)$sidebars) as $sidebar)
	{
		if(sorto_set($sidebar , 'topcopy')) continue ;
		
		$name = sorto_set( $sidebar, 'sidebar_name' );
		
		if( ! $name ) continue;
		$slug = sorto_bunch_slug( $name ) ;
		
		register_sidebar( array(
			'name' => $name,
			'id' =>  $slug ,
			'before_widget' => '<div id="%1$s" class="side-bar widget sidebar_widget %2$s">',
			'after_widget' => "</div>",
			'before_title' => '<div class="sec-title"><h3 class="skew-lines">',
			'after_title' => '</h3></div>',
		) );		
	}
	
	update_option('wp_registered_sidebars' , $wp_registered_sidebars) ;
}
add_action( 'widgets_init', 'sorto_bunch_widget_init' );
function sorto_load_head_scripts() {
	$options = _WSH()->option();
    if ( !is_admin() ) {
	$protocol = is_ssl() ? 'https://' : 'http://';
	$map_path = '?key='.sorto_set($options, 'map_api_key');	
    wp_enqueue_script( 'map_api', ''.$protocol.'maps.google.com/maps/api/js'.$map_path, array(), false, false );
	wp_enqueue_script( 'googlemap', get_template_directory_uri().'/js/googlemaps.js', array(), false, false );
	wp_enqueue_script( 'html5shiv', get_template_directory_uri().'/js/html5shiv.js', array(), false, false );
	wp_script_add_data( 'html5shiv', 'conditional', 'lt IE 9' );
	wp_enqueue_script( 'respond-min', get_template_directory_uri().'/js/respond.min.js', array(), false, false );
	wp_script_add_data( 'respond-min', 'conditional', 'lt IE 9' );
	}
    }
    add_action( 'wp_enqueue_scripts', 'sorto_load_head_scripts' );
//global variables
function bunch_global_variable() {
    global $wp_query;
}
/*-------------------------------------------------------------*/

function sorto_enqueue_scripts() {
    //styles
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.css' );
	wp_enqueue_style( 'fontawesom', get_template_directory_uri() . '/css/font-awesome.css' );
	wp_enqueue_style( 'flaticon', get_template_directory_uri() . '/css/flaticon.css' );
	wp_enqueue_style( 'animate', get_template_directory_uri() . '/css/animate.css' );
	wp_enqueue_style( 'owl-theme', get_template_directory_uri() . '/css/owl.css' );
	wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/css/jquery.fancybox.css' );
	wp_enqueue_style( 'hover', get_template_directory_uri() . '/css/hover.css' );
	wp_enqueue_style( 'sorto_main-style', get_stylesheet_uri() );
	wp_enqueue_style( 'sorto_responsive', get_template_directory_uri() . '/css/responsive.css' );
	wp_enqueue_style( 'sorto_custom-style', get_template_directory_uri() . '/css/custom.css' );
	
	
    //scripts
	wp_enqueue_script('jquery-ui-core');
	wp_enqueue_script( 'bootstrap', get_template_directory_uri().'/js/bootstrap.min.js', array(), false, true );
	wp_enqueue_script( 'fancybox', get_template_directory_uri().'/js/jquery.fancybox.pack.js', array(), false, true );
	wp_enqueue_script( 'map-script', get_template_directory_uri().'/js/map-script.js', array(), false, true );
	wp_enqueue_script( 'mixitup', get_template_directory_uri().'/js/mixitup.js', array(), false, true );
	wp_enqueue_script( 'bxslider', get_template_directory_uri().'/js/bxslider.js', array(), false, true );
	wp_enqueue_script( 'owl', get_template_directory_uri().'/js/owl.js', array(), false, true );
	wp_enqueue_script( 'wow', get_template_directory_uri().'/js/wow.js', array(), false, true );
	wp_enqueue_script( 'sorto_main_script', get_template_directory_uri().'/js/script.js', array(), false, true );
	
}
add_action( 'wp_enqueue_scripts', 'sorto_enqueue_scripts' );
/*-------------------------------------------------------------*/
function sorto_theme_slug_fonts_url() {
    $fonts_url = '';
 
    /* Translators: If there are characters in your language that are not
    * supported by Lora, translate this to 'off'. Do not translate
    * into your own language.
    */
    $ubuntu = _x( 'on', 'Ubuntu font: on or off', 'sorto' );
	$droid = _x( 'on', 'Droid font: on or off', 'sorto' );
	$montserrat = _x( 'on', 'Montserrat font: on or off', 'sorto' );
	
    /* Translators: If there are characters in your language that are not
    * supported by Open Sans, translate this to 'off'. Do not translate
    * into your own language.
    */
    $open_sans = _x( 'on', 'Open Sans font: on or off', 'sorto' );
 
    if ( 'off' !== $ubuntu || 'off' !== $open_sans || 'off' !== $montserrat ) {
        $font_families = array();
 
        if ( 'off' !== $ubuntu ) {
            $font_families[] = 'Ubuntu:400,400italic,500,500italic,700,700italic';
        }
		
		if ( 'off' !== $montserrat ) {
            $font_families[] = 'Montserrat:400,700';
        }
		
		if ( 'off' !== $open_sans ) {
            $font_families[] = 'Open Sans:400,400italic,600,600italic,700,700italic';
        }
 
        $query_args = array(
            'family' => urlencode( implode( '|', $font_families ) ),
            'subset' => urlencode( 'latin,latin-ext' ),
        );
 
        $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
    }
 
    return esc_url_raw( $fonts_url );
}
function sorto_theme_slug_scripts_styles() {
    wp_enqueue_style( 'sorto-theme-slug-fonts', sorto_theme_slug_fonts_url(), array(), null );
}
add_action( 'wp_enqueue_scripts', 'sorto_theme_slug_scripts_styles' );
/*---------------------------------------------------------------------*/
function sorto_add_editor_styles() {
    add_editor_style( 'custom-editor-style.css' );
}
add_action( 'admin_init', 'sorto_add_editor_styles' );
