<?php bunch_global_variable(); 
	$options = _WSH()->option();
	get_header(); 
	$settings  = _WSH()->option(); 
	if(sorto_set($_GET, 'layout_style')) $layout = sorto_set($_GET, 'layout_style'); else
	$layout = sorto_set( $settings, 'author_page_layout', 'right' );
	$sidebar = sorto_set( $settings, 'author_page_sidebar', 'blog-sidebar' );
	$view = sorto_set( $settings, 'author_page_view', 'list' );
	_WSH()->page_settings = array('layout'=>$layout, 'sidebar'=>$sidebar);
	$classes = ( !$layout || $layout == 'full' || sorto_set($_GET, 'layout_style')=='full' ) ? ' col-lg-12 col-md-12 col-sm-12 col-xs-12 ' : ' col-lg-8 col-md-8 col-sm-12 col-xs-12 ' ;
	if($layout == 'both') $classes = ' col-lg-6 col-md-6 col-sm-6 col-xs-12 ';  
	$bg = sorto_set($settings, 'author_page_header_img');
	$title = sorto_set($settings, 'author_page_header_title');
	$year = sorto_set($settings, 'author_page_header_year');
?>
<!--Page Title-->
<section class="page-title" <?php if($bg):?>style="background-image:url('<?php echo esc_attr($bg)?>');"<?php endif;?>>
    <div class="auto-container text-center">
    
        <h4 class="small-text"><?php if($year) echo balanceTags($year);?></h4>
        <h2 class="page-name"><?php if($title) echo balanceTags($title); else wp_title('');?></h2>
        
        <!--Bread Crumb-->
        <div class="bread-crumb clearfix">
        	<?php echo balanceTags(sorto_get_the_breadcrumb()); ?>
        </div>
        
    </div>
</section>

<!--Sidebar Page-->
<div class="sidebar-page-container">
    <!--Tabs Box-->
    <div class="auto-container">
        
        <div class="row clearfix">
		<!-- sidebar area -->
			<?php if( $layout == 'left' ): ?>
			<?php if ( is_active_sidebar( $sidebar ) ) { ?>
			<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">       
				<aside class="sidebar">
					<?php dynamic_sidebar( $sidebar ); ?>
				</aside>
			</div>
			<?php }?>
			<?php endif; ?>
            
			<!-- Left Content -->
			<div class="content-side <?php echo esc_attr($classes);?>">
            	<!--Blog Section / Classic View-->
                <section class="blog-section classic-view no-padd-bottom no-padd-top">
		
					<?php while( have_posts() ): the_post();?>
                            <!-- blog post item -->
                            <!-- Post -->
                            <div id="post-<?php the_ID(); ?>" <?php post_class();?>>
                                <?php get_template_part( 'blog' ); ?>
                            <!-- blog post item -->
                            </div><!-- End Post -->
                    <?php endwhile;?> 
                    
                    <!-- Styled Pagination -->
                    <div class="styled-pagination text-left">
                        <?php sorto_the_pagination(); ?>
                    </div>
                
                </section>
			</div>
			
            <!-- sidebar area -->
			
			<?php if( $layout == 'right' ): ?>
			<?php if ( is_active_sidebar( $sidebar ) ) { ?>
			<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">       
				<aside class="sidebar">
					<?php dynamic_sidebar( $sidebar ); ?>
				</aside>
			</div>
			<?php }?>
			<?php endif; ?>
			<!-- sidebar area -->
		</div>
	</div>
</div>

<?php get_footer(); ?>