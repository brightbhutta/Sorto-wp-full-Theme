<?php
/// Contact info 
class Bunch_About_Author extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Bunch_About_Author', /* Name */esc_html__('Sorto About Author','sorto'), array( 'description' => esc_html__('Show the Information about Author', 'sorto' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo balanceTags($before_widget); ?>
		
		<!-- About Me -->
        <div class="about-me wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
            <?php echo balanceTags($before_title.$title.$after_title); ?>
            
            <figure class="image-box"><img src="<?php echo esc_url($instance['img_url']);?>" alt="<?php esc_html_e('Image', 'sorto');?>"></figure>
            <div class="content">
                <h3><?php echo balanceTags($instance['author_title']);?></h3>
                <h4><?php echo balanceTags($instance['designation']);?></h4>
                <div class="text"><?php echo balanceTags($instance['content']);?></div>
            </div>
            
        </div>
		
		<?php echo balanceTags($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['img_url'] = $new_instance['img_url'];
		$instance['author_title'] = $new_instance['author_title'];
		$instance['designation'] = $new_instance['designation'];
		$instance['content'] = $new_instance['content'];
		
		
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('About Author', 'sorto');
		$img_url = ( $instance ) ? esc_attr($instance['img_url']) : 'http://codeisok.com/wp/sorto/wp-content/themes/sorto/images/resource/featured-image-5.jpg';
		$author_title = ( $instance ) ? esc_attr($instance['author_title']) : esc_html__('Muhammad Hashim', 'sorto');
		$designation = ( $instance ) ? esc_attr($instance['designation']) : esc_html__('Expert UX Designer', 'sorto');
		$content = ( $instance ) ? esc_attr($instance['content']) : '';
		
		?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
		
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('img_url')); ?>"><?php esc_html_e('Image Link here:', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('img_url')); ?>" name="<?php echo esc_attr($this->get_field_name('img_url')); ?>" type="text" value="<?php echo esc_attr( $img_url ); ?>" />
        </p>
		<p>
            <label for="<?php echo esc_attr($this->get_field_id('author_title')); ?>"><?php esc_html_e('Author Name:', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('author_title')); ?>" name="<?php echo esc_attr($this->get_field_name('author_title')); ?>" type="text" value="<?php echo esc_attr( $author_title ); ?>" />
        </p>
		<p>
            <label for="<?php echo esc_attr($this->get_field_id('designation')); ?>"><?php esc_html_e('Designation:', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('designation')); ?>" name="<?php echo esc_attr($this->get_field_name('designation')); ?>" type="text" value="<?php echo esc_attr( $designation ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Text:', 'sorto'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo balanceTags($content); ?></textarea>
        </p>
		
		<?php 
	}
	
}

/// Recent Posts 
class Bunch_Recent_Post_With_Image extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Bunch_Recent_Post_With_Image', /* Name */esc_html__('Sorto Recent Posts with image','sorto'), array( 'description' => esc_html__('Show the recent posts with images', 'sorto' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo balanceTags($before_widget); ?>
		
		<!-- Recent Posts -->
        <div class="recent-posts wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
            <?php echo balanceTags($before_title.$title.$after_title); ?>
            
            <?php $query_string = 'posts_per_page='.$instance['number'];
					if( $instance['cat'] ) $query_string .= '&cat='.$instance['cat'];
					query_posts( $query_string ); 
					
					$this->posts();
					wp_reset_query();
			?>
            
        </div>
		 
		<?php echo balanceTags($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Recent News', 'sorto');
		$number = ( $instance ) ? esc_attr($instance['number']) : 5;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
       
    	<p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'sorto'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'sorto'), 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts()
	{
		
		if( have_posts() ):?>
        
           	<!-- Title -->
				<?php while( have_posts() ): the_post(); ?>
                    
                    <article class="post">
                        <figure class="post-thumb"><?php the_post_thumbnail('sorto_80x80');?></figure>
                        <h4><a href="<?php echo esc_url(get_permalink(get_the_id()));?>"><?php echo balanceTags(sorto_trim(get_the_title(), 7));?></a></h4>
                        <div class="post-info"><?php echo get_the_date('F d, Y');?></div>
                    </article>
                    
				<?php endwhile; ?>
                
        <?php endif;
    }
}

///----footer widgets---

//Sorto About Us
class Bunch_About_Sorto extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Bunch_About_Sorto', /* Name */esc_html__('About Sorto','sorto'), array( 'description' => esc_html__('Show the information about Sorto', 'sorto' )) );
	}
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo balanceTags($before_widget);?>
      		
			<div class="about-widget">
                <?php echo balanceTags($before_title.$title.$after_title); ?>
                <div class="text">
                    <p><?php echo balanceTags($instance['content']); ?></p>
                </div>
                <?php if( $instance['show'] ): ?>
                <div class="social-links">
                    <?php echo balanceTags(sorto_bunch_get_social_icons()); ?>
                </div>
                <?php endif;?>
            </div>
			
		<?php
		
		echo balanceTags($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] =$new_instance['title'];
		$instance['content'] = $new_instance['content'];
		$instance['show'] = $new_instance['show'];
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'About Sorto';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$show = ( $instance ) ? esc_attr($instance['show']) : '';?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('title:', 'sorto'); ?></label>
            <input placeholder="<?php esc_html_e('logo title here', 'sorto');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'sorto'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo balanceTags($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show')); ?>"><?php esc_html_e('Show Social Icons:', 'sorto'); ?></label>
			<?php $selected = ( $show ) ? ' checked="checked"' : ''; ?>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('show')); ?>"<?php echo esc_attr($selected); ?> name="<?php echo esc_attr($this->get_field_name('show')); ?>" type="checkbox" value="true" />
        </p>        
                
		<?php 
	}
	
}

/// Latest News 
class Bunch_Latest_News extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Bunch_Latest_News', /* Name */esc_html__('Sorto Latest News','sorto'), array( 'description' => esc_html__('Show the latest news', 'sorto' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo balanceTags($before_widget); ?>
		
		<!--Footer Column-->
        <div class="latest-news">
            <?php echo balanceTags($before_title.$title.$after_title); ?>
            <!--News Item-->
            <?php $query_string = 'posts_per_page='.$instance['number'];
					if( $instance['cat'] ) $query_string .= '&cat='.$instance['cat'];
					query_posts( $query_string ); 
					
					$this->posts();
					wp_reset_query();
			?>
        </div>
		 
		<?php echo balanceTags($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Latest News', 'sorto');
		$number = ( $instance ) ? esc_attr($instance['number']) : 2;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
       
    	<p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'sorto'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'sorto'), 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts()
	{
		
		if( have_posts() ):?>
        
           	<!-- Title -->
				<?php while( have_posts() ): the_post(); ?>
                    
                    <!--News Item-->
                    <div class="news-item">
                        <a href="<?php echo esc_url(get_permalink(get_the_id()));?>" class="news-title"><?php echo balanceTags(sorto_trim(get_the_title(), 8));?></a>
                        <div class="update-time"><?php echo get_the_date('F d, Y');?></div>
                    </div>
                    
				<?php endwhile; ?>
                
        <?php endif;
    }
}

/// Flicker Gallery 
class Bunch_Flicker_Gallery extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Bunch_Flicker_Gallery', /* Name */esc_html__('Sorto Flicker Gallery','sorto'), array( 'description' => esc_html__('Show the Gallery Images', 'sorto' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo balanceTags($before_widget); ?>
		
		<!--Footer Column-->
        <div class="footer-widget gallery-widget">
            <?php echo balanceTags($before_title.$title.$after_title); ?>
            
            <?php 
				$args = array('post_type' => 'bunch_gallery', 'showposts'=>$instance['number']);
				if( $instance['cat'] ) $args['tax_query'] = array(array('taxonomy' => 'gallery_category','field' => 'id','terms' => (array)$instance['cat']));
				query_posts($args); 
					
					$this->posts();
					wp_reset_query();
			?>
            
        </div>
		
		<?php echo balanceTags($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Flickr Widget', 'sorto');
		$number = ( $instance ) ? esc_attr($instance['number']) : 6;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
       
    	<p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'sorto'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'sorto'), 'selected'=>$cat, 'taxonomy' => 'gallery_category', 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts()
	{
		
		if( have_posts() ):?>
        
           	<!-- Title -->
			<div class="clearfix">
                
                <?php while( have_posts() ): the_post(); 
					global $post;
					$gallery_meta = _WSH()->get_meta();
				?>
                
                <?php 
					$post_thumbnail_id = get_post_thumbnail_id($post->ID);
					$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
				?>
                
                <figure class="image"><a href="<?php echo esc_url($post_thumbnail_url);?>" class="lightbox-image" title="<?php esc_html_e('Caption Here', 'sorto');?>"><?php the_post_thumbnail('sorto_80x80');?></a></figure>
                <?php endwhile; ?>
            
            </div>
			
        <?php endif;
    }
}

/// External Pages
class Bunch_External_Links extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Bunch_External_Links', /* Name */esc_html__('Sorto External Pages','sorto'), array( 'description' => esc_html__('Show the external Pages', 'sorto' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo balanceTags($before_widget); ?>
		
		<!--Sidebar Widget / Styled Nav-->
        <div class="styled-nav">
            <nav class="nav-outer">
                <?php 
					$args = array('post_type' => 'bunch_services', 'showposts'=>$instance['number']);
					if( $instance['cat'] ) $args['tax_query'] = array(array('taxonomy' => 'services_category','field' => 'id','terms' => (array)$instance['cat']));
					query_posts($args); 
						
						$this->posts();
						wp_reset_query();
				?>
            </nav>
        </div>
		 
		<?php echo balanceTags($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$number = ( $instance ) ? esc_attr($instance['number']) : 7;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'sorto'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
       
    	<p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'sorto'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'sorto'), 'selected'=>$cat, 'taxonomy' => 'services_category', 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts()
	{
		
		if( have_posts() ):?>
        
           	<ul>
                <?php while( have_posts() ): the_post();
				$services_meta = _WSH()->get_meta();
				 ?>
                 
                	<li class=""><a href="<?php echo esc_url(sorto_set($services_meta, 'ext_url'));?>"><?php the_title();?></a></li>
                <?php endwhile; ?>            
            </ul>
                
        <?php endif;
    }
}

//Sorto About Us
class Bunch_Contact_Info extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Bunch_Contact_Info', /* Name */esc_html__('Sorto Contact Agent','sorto'), array( 'description' => esc_html__('Show the Contact Information', 'sorto' )) );
	}
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo balanceTags($before_widget);?>
      		
			<!--Sidebar Widget / Contact Widget-->
            <div class="contact-widget">
                <h3><?php esc_html_e('Have Questions?','sorto');?><br><?php esc_html_e('Call Us:','sorto');?></h3>
                <div class="phone-numbers">
                    <?php echo balanceTags($instance['phone']); ?>
                </div>
            </div>
			
		<?php
		
		echo balanceTags($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['phone'] = $new_instance['phone'];
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$phone = ($instance) ? esc_attr($instance['phone']) : '(+92) 123 456 7896';?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('phone')); ?>"><?php esc_html_e('phone:', 'sorto'); ?></label>
            <input placeholder="<?php esc_html_e('phone', 'sorto');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('phone')); ?>" name="<?php echo esc_attr($this->get_field_name('phone')); ?>" type="text" value="<?php echo esc_attr($phone); ?>" />
        </p>    
                
		<?php 
	}
	
}


