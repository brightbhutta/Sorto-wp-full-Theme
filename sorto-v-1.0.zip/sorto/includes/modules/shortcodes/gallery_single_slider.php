<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_gallery' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['gallery_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   

<!--Single Item Carousel-->
<div class="carousel-outer">
    <ul class="single-item-carousel">
         <?php while($query->have_posts()): $query->the_post();
			global $post ; 
			$gallery_meta = _WSH()->get_meta();
		?>
        <?php 
			$post_thumbnail_id = get_post_thumbnail_id($post->ID);
			$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
		?>
        <li class="slide-item"><a href="<?php esc_url($post_thumbnail_url);?>" class="lightbox-image" title="<?php esc_html_e('Image Caption Here', 'sorto');?>"><?php the_post_thumbnail('1230x500');?></a></li>
        
		<?php endwhile; ?>
    </ul>
</div>  

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>