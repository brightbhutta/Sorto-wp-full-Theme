<?php
ob_start() ;?>

<!--Info Section-->
<section class="info-section">
    <div class="auto-container">
            
        <div class="row clearfix">
            <!--Info Column-->
            <div class="info-column col-md-4 col-sm-4 col-xs-12">
                <div class="info-box">
                    <div class="icon-box"><span class="flaticon-technology-5"></span></div>
                    <ul>
                        <li><?php esc_html_e('Phone:', 'sorto');?> <?php echo balanceTags($phone_no);?></li>
                        <li><?php esc_html_e('Fax:', 'sorto');?> <?php echo balanceTags($fax_no);?></li>
                    </ul>
                </div>
            </div>
            <!--Info Column-->
            <div class="info-column col-md-4 col-sm-4 col-xs-12">
                <div class="info-box">
                    <div class="icon-box"><span class="flaticon-letter-2"></span></div>
                    <ul>
                        <li><?php echo balanceTags($email_one);?></li>
                        <li><?php echo balanceTags($email_two);?></li>
                    </ul>
                </div>
            </div>
            <!--Info Column-->
            <div class="info-column col-md-4 col-sm-4 col-xs-12">
                <div class="info-box">
                    <div class="icon-box"><span class="flaticon-location-2"></span></div>
                    <ul>
                        <li><?php echo balanceTags($address_one);?> <br><?php echo balanceTags($address_two);?></li>
                    </ul>
                </div>
            </div>
        </div>
        
    </div>
</section>

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   