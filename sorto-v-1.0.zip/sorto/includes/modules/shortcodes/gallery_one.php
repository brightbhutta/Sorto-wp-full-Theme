<?php 
bunch_global_variable();
$args = array('post_type' => 'bunch_gallery', 'showposts'=>$num, 'orderby'=>$sort, 'order'=>$order);
$terms_array = explode(",",$exclude_cats);
if($exclude_cats) $args['tax_query'] = array(array('taxonomy' => 'gallery_category','field' => 'id','terms' => $terms_array,'operator' => 'NOT IN',));
$query = new WP_Query($args);
//query_posts($args);
//wp_enqueue_script( array( 'jquery-prettyphoto', 'cubeportfolio', 'main-script','jquery-isotope','portfolio' ) );
$t = $GLOBALS['_bunch_base'];
$data_filtration = '';
$data_posts = '';
?>
<?php if( $query->have_posts() ):
	
ob_start();?>
	<?php $count = 0; 
	$fliteration = array();?>
	<?php while( $query->have_posts() ): $query->the_post();
		global  $post;
		//$meta = get_post_meta( get_the_id(), '_bunch_gallery_meta', true );//sorto_printr($meta);
		$meta = _WSH()->get_meta();
		$post_terms = get_the_terms( get_the_id(), 'gallery_category');// sorto_printr($post_terms); exit();
		foreach( (array)$post_terms as $pos_term ) $fliteration[$pos_term->term_id] = $pos_term;
		$temp_category = get_the_term_list(get_the_id(), 'gallery_category', '', ', ');
	?>
		<?php $post_terms = wp_get_post_terms( get_the_id(), 'gallery_category'); 
		$term_slug = '';
		if( $post_terms ) foreach( $post_terms as $p_term ) $term_slug .= $p_term->slug.' ';?>		
		   <?php 
			$post_thumbnail_id = get_post_thumbnail_id($post->ID);
			$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
		   ?>     
			<!--Default Portfolio Item-->
            <div class="default-portfolio-item mix mix_all all <?php echo esc_attr($term_slug); ?> col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image"><?php the_post_thumbnail('sorto_340x210');?></figure>
                    <!--Overlay-->
                    <div class="overlay-box">
                        <div class="content-box">
                            <div class="content">
                                <h3><a href="<?php echo esc_url(sorto_set($meta, 'ext_url'));?>"><?php the_title();?></a></h3>
                                
								<?php /* for categories without anchor*/ $term_list = wp_get_post_terms(get_the_id(), 'gallery_category', array("fields" => "names")); ?>
                                	<div class="tags"><?php echo implode( ', ', (array)$term_list );?></div>
                                
                                <a href="<?php echo esc_url($post_thumbnail_url); ?>" class="zoom-btn lightbox-image" title="<?php esc_html_e('Awsome Title Here', 'sorto');?>"><span class="icon flaticon-cross"></span></a>
                            </div>
                        </div>
                        
                        <!--Lines -->
                        <span class="line-left"></span><span class="line-bottom"></span><span class="line-right"></span><span class="line-top"></span>
                    </div>
                </div>
            </div>

<?php endwhile;?>
<?php wp_reset_postdata();
$data_posts = ob_get_contents();
ob_end_clean();
endif; 
ob_start();?>	 
<?php $terms = get_terms(array('gallery_category')); ?>

<!--Gallery Section-->
<section class="gallery-section fullwidth">
    <div class="mixitup-gallery">
        
        <!--Filter-->
        <div class="filters text-center">
            <ul class="filter-tabs filter-btns clearfix">
                <li class="active filter" data-role="button" data-filter="all"><?php esc_html_e('All', 'sorto');?></li>
                <?php foreach( $fliteration as $t ): ?>
                <li class="filter" data-role="button" data-filter=".<?php echo esc_attr(sorto_set( $t, 'slug' )); ?>"><?php echo balanceTags(sorto_set( $t, 'name')); ?></li>
                <?php endforeach;?>
            </ul>
        </div>
        
        <div class="filter-list clearfix">
            <?php echo balanceTags($data_posts); ?>
        </div>
    </div>
    
    <div class="auto-container"><div class="text-center padd-top-50"><a href="<?php echo esc_url($btn_link);?>" class="theme-btn btn-style-two"><?php echo balanceTags($btn_text);?></a></div></div>
</section>

<?php $output = ob_get_contents();
ob_end_clean(); 
return $output;?>