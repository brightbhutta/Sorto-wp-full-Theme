<?php
ob_start() ;?>

<!--Features Section-->
<section class="features-section text-center">
    <div class="auto-container">
        <!--Section Title-->
        <div class="sec-title text-center">
            <h3><?php echo balanceTags($sub_title);?></h3>
            <h2><?php echo balanceTags($title);?></h2>
            <div class="slices"><span class="slice"></span><span class="slice"></span><span class="slice"></span></div>
        </div>
        
        <!--Bigger Image-->
        <figure class="bigger-image margin-bott-50"><img src="<?php echo esc_url(wp_get_attachment_url($image));?>" alt=""></figure>
        
    </div>
</section>

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   