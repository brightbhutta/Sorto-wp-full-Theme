<?php
ob_start() ;?>

<!--Default Section-->
<section class="default-section">
    <div class="auto-container">
        <div class="default-content text-center">
            <h2><?php echo balanceTags($title);?></h2>
            <div class="text"><?php echo balanceTags($text);?></div>
            <a href="<?php echo esc_url($purchase_now_link);?>" class="theme-btn btn-style-one"><?php echo balanceTags($purchase_btn);?></a>
            <a href="<?php echo esc_url($learn_more_link);?>" class="theme-btn btn-style-two"><?php echo balanceTags($learn_more_btn);?></a>
        </div>
    </div>
</section>

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   