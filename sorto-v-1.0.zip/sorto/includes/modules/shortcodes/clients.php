<?php  
ob_start() ;
$options = _WSH()->option();
?>

<!--Sponsors Section-->
<section class="sponsors-section">
    <div class="auto-container">
        <!--Sponsors SLider-->
        <ul class="sponsors-slider">
            <?php if($clients = sorto_set(sorto_set($options, 'clients'), 'clients')):?>
			<?php foreach($clients as $key => $value):?>
			<?php if(sorto_set($value, 'tocopy')) continue;?>
            	<li><a href="<?php echo esc_url(sorto_set($value, 'client_link'));?>"><img src="<?php echo esc_url(sorto_set($value, 'client_img'));?>" alt="<?php esc_html_e('image', 'sorto');?>"></a></li>
            <?php endforeach;?>
        	<?php endif;?>
        </ul>
    </div>
</section>

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   