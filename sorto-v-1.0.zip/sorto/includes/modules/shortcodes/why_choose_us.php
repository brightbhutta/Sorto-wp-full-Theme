<?php 
wp_enqueue_script('jquery-mixitup');
bunch_global_variable();
$count = 0;
$args = array('post_type' => 'bunch_services', 'showposts'=>$num, 'orderby'=>$sort, 'order'=>$order);
 if( $cat ) $args['services_category'] = $cat;
$query = new WP_Query($args);
$data_list = array();
$data_post = array();
$gal_features = '';
?>
<?php if( $query->have_posts() ):
while( $query->have_posts() ): $query->the_post();
	global  $post;
	$meta1 = _WSH()->get_meta();
	$active_list = ($count == 1) ? 'active-btn' : '';
	$active_tab = ($count == 1) ? 'active-tab' : '';
	$features = explode("\n", sorto_set($meta1, 'gal_features'));
	foreach($features as $key => $value){
		$gal_features .= '<li>'.$value.'</li>';
	}
	$data_list[get_the_id()] = '<a href="#tab-one'.get_the_id().'" class="tab-btn '.$active_list.'">'.get_the_title(get_the_id()).'</a>';
	$data_post[get_the_id()] = '<div class="tab '.$active_tab.'" id="tab-one'.get_the_id().'">
									<div class="row clearfix">
										<!--Content Column-->
										<div class="content-column col-lg-7 col-sm-7 col-xs-12">
											<h3>'.get_the_title().'</h3>
											<div class="upper-content">
												<div class="text">
													'.get_the_content().'
												</div>
											</div>
										</div>
										
										<!--Image Column-->
										<div class="image-column col-lg-5 col-sm-5 col-xs-12">
											<figure class="image-box">'.get_the_post_thumbnail(get_the_id(),'sorto_520x320').'<div class="over-layer"><span class="left-layer"></span><span class="right-layer"></span></div></figure>
										</div>
										
									</div>
								</div>';
$gal_features= '';
$count++; 
endwhile;
?>
<?php 
endif;
wp_reset_postdata();
ob_start();?>	 

<?php $terms = get_terms(array('gallery_category')); ?>

 <!--Tabs Section-->
<section class="tabs-section default-section with-padding">
    <div class="auto-container">
        <!--Section Title-->
        <div class="sec-title text-center">
            <?php if($sub_title):?><h3><?php echo balanceTags($sub_title);?></h3><?php endif;?>
            <h2><?php echo balanceTags($title);?></h2>
            <div class="slices"><span class="slice"></span><span class="slice"></span><span class="slice"></span></div>
        </div>
        
        <div class="outer-container">
            <!--Tabs Box-->
            <div class="tabs-box">
                
                <!--Tab Buttons-->
                <div class="tab-buttons clearfix">
                    <?php echo implode("\n",(array)$data_list);?>                                                                                                             
                </div>
                
                <!--Tabs Content-->
                <div class="tab-content">
                    <?php echo implode("\n",(array)$data_post);?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $output = ob_get_contents();
ob_end_clean(); 
return $output;?>