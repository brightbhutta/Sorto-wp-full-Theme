<?php ob_start(); ?>

<!--Progress Box-->
<div class="progress-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="0ms">
    <div class="box-title"><?php echo balanceTags($title);?></div>
    <div class="inner">
        <div class="bar">
            <div class="bar-innner"><div class="bar-fill" data-percent="<?php echo balanceTags($values);?>"><div class="percent"></div></div></div>
        </div>
    </div>
</div>

<?php return ob_get_clean(); 