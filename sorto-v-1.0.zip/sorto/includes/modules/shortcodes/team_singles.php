<?php ob_start(); ?>

<!--Member Details-->
<section class="member-details default-three-column">
    <div class="auto-container">
        
        <div class="row clearfix">
            
            <!--Image Column-->
            <div class="column image-column col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box"><a href="<?php echo esc_url($email);?>"><img src="<?php echo esc_url(wp_get_attachment_url($image));?>" alt=""></a></figure>
                </div>
            </div>
            
            <!--Image Column-->
            <div class="column text-column col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <h3><?php echo balanceTags($title);?></h3>
                    <div class="text"><?php echo balanceTags($text);?></div>
                    <div class="default-social-links">
                        <a href="<?php echo esc_url($facebook_link);?>"><span class="fa fa-facebook-f"></span></a>
                        <a href="<?php echo esc_url($twitter_link);?>"><span class="fa fa-twitter"></span></a>
                        <a href="<?php echo esc_url($google_link);?>"><span class="fa fa-google-plus"></span></a>
                        <a href="<?php echo esc_url($instagram_link);?>"><span class="fa fa-instagram"></span></a>
                    </div>
                </div>
            </div>
            
            <!--Skills Column-->
            <div class="column skills-column col-md-4 col-sm-12 col-xs-12">
                <div class="inner-box">
                    <!--Progress Levels-->
                    <div class="progress-levels">
                    	<?php echo do_shortcode( $contents );?>      
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

<?php return ob_get_clean(); ?>