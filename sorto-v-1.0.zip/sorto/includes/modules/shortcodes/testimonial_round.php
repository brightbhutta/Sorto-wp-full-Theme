<?php  
   $count = 1;
   $count_index = 0;
   $query_args = array('post_type' => 'bunch_testimonials' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['testimonials_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   $data_filtration = array();
   $data_content = array();
   ?>
   
<?php if($query->have_posts()):  ?>
<?php while($query->have_posts()): $query->the_post();
	  global $post ; 
	  $client_meta = _WSH()->get_meta();
	  $active = ($count == 1) ? 'active' : '';
	  
	  $data_filtration[get_the_id()] = '<div class="slide-item">
											<div class="slide-text">'.get_the_content($post->ID).'</div>
											<div class="slide-info">
												<h4 class="author-title">'.get_the_title($post->ID).'</h4>
												<div class="designation">'.sorto_set($client_meta, 'designation').'</div>
											</div>
										</div>';
	 									
	  $data_content[get_the_id()] = '<a class="pager '.$active.'" data-slide-index="'.$count_index.'" href="'.esc_url(sorto_set($client_meta, 'ext_url')).'"><div class="image img-circle">'.get_the_post_thumbnail( $post->ID, 'thumbnail', array('class' => 'img-circle')).'</div></a>';
									
?>
<?php $count++; $count_index++; endwhile; endif;
wp_reset_postdata();
ob_start() ;
?>  

<!--Testimonials Style One-->
<section class="testimonials-section testimonials-style-one">
    <div class="auto-container">
        
        <!--Section Title-->
        <div class="sec-title text-center">
            <h3><?php echo balanceTags($sub_title);?></h3>
            <h2><?php echo balanceTags($title);?></h2>
            <div class="slices"><span class="slice"></span><span class="slice"></span><span class="slice"></span></div>
        </div>
        
        <div class="slider-outer">
            <div class="row clearfix">
            	<!--Column / Slides-->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 column slides-column pull-right">
                    <div class="inner-box">
                        <div class="testimonials-slider">
                        	<?php foreach($data_filtration as $key => $value):?>
								<?php echo balanceTags($value);?>
                            <?php endforeach;?>
                        </div>
                    </div>
                </div>
                
                <!--Column / Custom Pager-->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 column pager-column pull-left">
                    <div class="inner-box">
                        <div class="testimonials-pager clearfix" id="testimonials-pager">
                           <?php foreach($data_content as $key => $content):?>
								<?php echo balanceTags($content);?>
                           <?php endforeach;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>