<?php ob_start(); ?>

<!--Pricing Section-->
<section class="pricing-section bg-lightgrey">
    <div class="auto-container">
        <!--Section Title-->
        <div class="sec-title text-center">
            <h3><?php echo balanceTags($sub_title);?></h3>
            <h2><?php echo balanceTags($title);?></h2>
            <div class="slices"><span class="slice"></span><span class="slice"></span><span class="slice"></span></div>
        </div>
        
        <div class="row clearfix">
            <?php echo do_shortcode( $contents );?>
        </div>
    </div>
</section>

<?php return ob_get_clean(); ?>