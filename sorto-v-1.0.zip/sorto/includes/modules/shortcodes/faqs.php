<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_faqs' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   if( $cat ) $query_args['faqs_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>

<!--FAQs Section-->
<section class="faqs-section">
    <div class="auto-container">
        
        <div class="row clearfix">
            <?php while($query->have_posts()): $query->the_post();
				global $post ; 
				$faqs_meta = _WSH()->get_meta();
			?>
            <!--Column-->
            <div class="column col-md-6 col-sm-12 col-xs-12">
                <!--Faq Block-->
                <div class="faq-block">
                    <h4><?php the_title();?></h4>
                    <div class="text"><?php echo balanceTags(sorto_trim(get_the_content(), $text_limit));?></div>
                </div>
            </div>
            <?php endwhile;?>
        </div>
    </div>
</section>
    
<?php endif; ?>

<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>