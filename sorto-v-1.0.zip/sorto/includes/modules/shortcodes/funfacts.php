<?php ob_start(); ?>

<!--Fact Counter Section-->
<section class="fact-counter-section">
    <div class="auto-container">
        <div class="row clearfix">
            
            <!--Content Column-->
            <div class="column content-column col-lg-6 col-md-12 col-sm-12">
                <div class="inner-box">
                    <!--Section Title-->
                    <div class="sec-title text-left">
                        <h3><?php echo balanceTags($sub_title);?></h3>
                        <h2><?php echo balanceTags($title);?></h2>
                        <div class="slices"><span class="slice"></span><span class="slice"></span><span class="slice"></span></div>
                    </div>
                    <div class="text"><?php echo balanceTags($text);?></div>
                    <a href="<?php echo esc_url($btn_link);?>" class="theme-btn btn-style-three"><?php echo balanceTags($btn_text);?></a>
                </div>
            </div>
            
            <!--Facts Column-->
            <div class="column facts-column col-lg-6 col-md-12 col-sm-12">
                <!--Fact Counter-->
                <div class="fact-counter inner-box">
                    <div class="clearfix">
                        <?php echo do_shortcode( $contents );?>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

<?php return ob_get_clean(); ?>