<?php
ob_start() ;?>

<!--Newsletter Section-->
<section class="newsletter-section">
    <div class="auto-container">
        <!--Section Title-->
        <div class="sec-title text-center">
            <h3><?php echo balanceTags($sub_title);?></h3>
            <h2><?php echo balanceTags($title);?></h2>
            <div class="slices"><span class="slice"></span><span class="slice"></span><span class="slice"></span></div>
        </div>
        
        <!--Newsletter FOrm-->
        <div class="newsletter-form">
            <form method="post" action="http://feedburner.google.com/fb/a/mailverify" accept-charset="utf-8">
                <div class="form-group">
                    <input type="email" name="email" value="" placeholder="<?php esc_html_e('Enter Email Here', 'sorto')?>" required>
                    <button type="submit" class="theme-btn"><?php esc_html_e('Subscribe', 'sorto')?></button>
                </div>
            </form>
        </div>
        
    </div>
</section>

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   