<?php 
ob_start();
?>

<!--Contact Section / Style Two-->
<section class="contact-section style-two bg-lightgrey">

    <div class="auto-container">
        <div class="outer-container">
            <div class="clearfix">
                
                <!--Form Column-->
                <div class="form-column col-md-8 col-sm-12 col-xs-12">
                    <h3><?php echo balanceTags($title);?></h3>
                    
                    <div class="form-outer default-form">
                        <?php echo do_shortcode(bunch_base_decode($contact_form_two));?>
                    </div>
                </div>
                
                <!--Map Column-->
                <div class="map-column col-md-4 col-sm-12 col-xs-12">
                    <!--Map Container-->
                    <div class="map-container">
                        <!--Map Canvas-->
                        <div class="map-canvas"
                            data-zoom="13"
                            data-lat="<?php echo balanceTags($lat);?>"
                            data-lng="<?php echo balanceTags($long);?>"			  
                            data-type="roadmap"
                            data-hue="#ffc400"
                            data-title="<?php esc_html_e('Envato', 'sorto');?>"
                            data-content="Melbourne VIC 3000, Australia<br><a href='mailto:<?php echo esc_url($email);?>'><?php echo balanceTags($email);?></a>">
                        </div>
                        
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>

<?php return ob_get_clean();?>		