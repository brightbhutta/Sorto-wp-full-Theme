<?php ob_start(); ?>

<!--Counter Column-->
<article class="counter-column wow fadeIn" data-wow-duration="0ms">
    <div class="icon-box"><span class="<?php echo esc_attr(str_replace("icon ",'', $icon));?>"></span></div>
    <div class="count-outer"><span class="count-text" data-speed="1500" data-stop="<?php echo balanceTags($value_end);?>"><?php echo balanceTags($value_start);?></span><?php esc_html_e('+', 'sorto');?></div>
    <div class="title"><?php echo balanceTags($title);?></div>
</article>

<?php return ob_get_clean(); 