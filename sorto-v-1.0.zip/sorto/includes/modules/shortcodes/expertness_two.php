<?php
ob_start() ;?>

<!--Skills Section-->
<section class="skills-section style-two" style="background-image:url('<?php echo esc_url(wp_get_attachment_url($image)); ?>');">
    
    <div class="auto-container">
        <!--Section Title-->
        <div class="sec-title text-center">
            <h3><?php echo balanceTags($subtitle);?></h3>
            <h2><?php echo balanceTags($title);?></h2>
            <div class="slices"><span class="slice"></span><span class="slice"></span><span class="slice"></span></div>
        </div>
        
        <!--Content Container-->
        <div class="content-container">
            <div class="row clearfix">
                <!--Content Column-->
                <div class="content-column col-md-4 col-sm-12 col-xs-12">
                    <div class="inner-box">
                        <h3><?php echo balanceTags($inner_title);?></h3>
                        <div class="text"><?php echo balanceTags($inner_text);?></div>
                        <div class="link"><a href="<?php echo esc_url($btn_link);?>" class="read-more"><?php echo balanceTags($btn_text);?> <span class="fa fa-long-arrow-right"></span></a></div>
                    </div>
                </div>
                
                <!--Skills Column-->
                <div class="skills-column col-md-8 col-sm-12 col-xs-12">
                    <div class="inner-box">
                        <!--Progress Levels-->
                        <div class="progress-levels">
                            <div class="row clearfix">
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <!--Progress Box-->
									<?php $skills_array = (array)json_decode(urldecode($expert_skills));

										if( $skills_array && is_array($skills_array) ): 
										foreach( (array)$skills_array as $value ):
									?>
                                    <div class="progress-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="0ms">
                                        <div class="box-title"><?php echo balanceTags(sorto_set( $value, 'skill_title' )); ?></div>
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-innner"><div class="bar-fill" data-percent="<?php echo esc_attr(sorto_set( $value, 'skill_percent' )); ?>"><div class="percent"></div></div></div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; endif;?>
                                    
                                </div>
                                
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <!--Progress Box-->
									<?php $skills_array2 = (array)json_decode(urldecode($expert_skills2));

										if( $skills_array2 && is_array($skills_array2) ): 
										foreach( (array)$skills_array2 as $value ):
									?>
                                    <div class="progress-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="0ms">
                                        <div class="box-title"><?php echo balanceTags(sorto_set( $value, 'skill_title' )); ?></div>
                                        <div class="inner">
                                            <div class="bar">
                                                <div class="bar-innner"><div class="bar-fill" data-percent="<?php echo esc_attr(sorto_set( $value, 'skill_percent' )); ?>"><div class="percent"></div></div></div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; endif;?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   