<?php ob_start(); ?>

<!--Price Table-->
<div class="pricing-table col-md-3 col-sm-6 col-xs-12">
    <div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
        <div class="table-header">
            <?php if($icon):?><div class="icon-right"><span class="<?php echo esc_attr(str_replace("icon ","", $icon));?>"></span></div><?php endif;?>
            <h3 class="price"><?php echo balanceTags($currency_symbol);?><?php echo balanceTags($price);?></h3>
            <h4 class="title"><?php echo balanceTags($title);?></h4>
        </div>
        
        <div class="table-content">
            <ul>
                <?php $fearures = explode("\n",$feature_str);?>
                <?php foreach($fearures as $feature):?>
                	<li><?php echo balanceTags($feature);?></li>
                <?php endforeach;?>
            </ul>
        </div>
        
        <div class="table-footer">
            <a href="<?php echo esc_url($btn_link);?>" class="theme-btn btn-style-three rounded-btn"><?php echo balanceTags($btn_text);?></a>
        </div>
    </div>
</div>

<?php return ob_get_clean(); 