<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_team' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   if( $cat ) $query_args['team_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>
<!--Team Section-->
<section class="team-section bg-lightgrey">
    <div class="auto-container">
        <!--Section Title-->
        <?php if($sub_title || $title):?>
            <div class="sec-title text-center">
                <h3><?php echo balanceTags($sub_title);?></h3>
                <h2><?php echo balanceTags($title);?></h2>
                <div class="slices"><span class="slice"></span><span class="slice"></span><span class="slice"></span></div>
            </div>
        <?php endif;?>
        <div class="row clearfix">
            
            <!--Team Member-->
            <?php while($query->have_posts()): $query->the_post();
				global $post ; 
				$teams_meta = _WSH()->get_meta();
			?>
            <div class="column team-member col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <figure class="image-box"><a href="<?php echo esc_url(sorto_set($teams_meta, 'team_link'));?>"><?php the_post_thumbnail('sorto_370x230');?></a></figure>
                    <div class="content-box">
                        <h3><a href="<?php echo esc_url(sorto_set($teams_meta, 'team_link'));?>"><?php the_title();?></a></h3>
                        <div class="designation"><?php echo balanceTags(sorto_set($teams_meta, 'designation'));?></div>
                        <div class="text"><?php echo balanceTags(sorto_trim(get_the_content(), $text_limit));?></div>
                    </div>
                    <?php if($socials = sorto_set($teams_meta, 'bunch_team_social')):?>
                    <div class="social-links">
                        <?php foreach($socials as $key => $value):?>
							<a href="<?php echo esc_url(sorto_set($value, 'social_link'));?>"><span class="fa <?php echo esc_attr(sorto_set($value, 'social_icon'));?>"></span></a>
                        <?php endforeach;?>
                    </div>
                    <?php endif;?>
                </div>
            </div>
            <?php endwhile;?>
            
         </div>
         
         <?php if($btn_link || $btn_text):?>
         	<div class="text-center padd-top-20 padd-bott-50"><a href="<?php echo esc_url($btn_link);?>" class="theme-btn btn-style-two"><?php echo balanceTags($btn_text);?></a></div>
    	 <?php endif;?>
    </div>
</section>
 
<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>