<?php 
ob_start();
?>

<!--Contact Section-->
<section class="contact-section bg-lightgrey">

    <div class="auto-container">
        <div class="outer-container">
            <div class="clearfix">
                
                <!--Form Column-->
                <div class="form-column col-md-8 col-sm-12 col-xs-12">
                    <h3><?php echo balanceTags($form_title);?></h3>
                    
                    <div class="form-outer default-form">
                       <?php echo do_shortcode(bunch_base_decode($contact_form_one));?> 
                    </div>
                </div>
                
                <!--Info Column-->
                <div class="info-column col-md-4 col-sm-12 col-xs-12">
                    <div class="inner-box">
                        <h3><?php echo balanceTags($info_title);?></h3>
                        <!--Contact Info-->
                        <ul class="contact-info">
                            <li><div class="icon"><span class="flaticon-location-2"></span></div><?php echo balanceTags($address1);?> <br><?php echo balanceTags($address2);?></li>
                            <li><div class="icon"><span class="flaticon-telephone"></span></div><?php echo balanceTags($phone1);?> <br><?php echo balanceTags($phone2);?></li>
                            <li><div class="icon"><span class="flaticon-e-mail-envelope"></span></div><?php echo balanceTags($email1);?><br><?php echo balanceTags($email2);?></li>
                        </ul>
                        <div class="default-social-links">
                            <a href="<?php echo esc_url($facebook_link);?>"><span class="fa fa-facebook-f"></span></a>
                            <a href="<?php echo esc_url($twitter_link);?>"><span class="fa fa-twitter"></span></a>
                            <a href="<?php echo esc_url($google_plus);?>"><span class="fa fa-google-plus"></span></a>
                            <a href="<?php echo esc_url($instagram_link);?>"><span class="fa fa-instagram"></span></a>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>

<?php return ob_get_clean();?>		