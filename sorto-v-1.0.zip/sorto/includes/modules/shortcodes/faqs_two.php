<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_faqs' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   if( $cat ) $query_args['faqs_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>

<!--FAQs Section-->
<section class="faqs-section">
    <div class="auto-container">
        
        <!--Accordion Box-->
        <ul class="accordion-box">
            <?php while($query->have_posts()): $query->the_post();
				global $post ; 
				$faqs_meta = _WSH()->get_meta();
			?>
            <!--Block-->
            <li class="accordion block">
                <div class="acc-btn <?php if($count==1) echo 'active'?>"><div class="icon-outer"><span class="icon fa icon-up fa-angle-up"></span> <span class="icon fa icon-down fa-angle-down"></span></div> <?php the_title();?></div>
                <div class="acc-content <?php if($count==1) echo 'current'?>">
                    <div class="content">
                        <?php echo the_content();?>
                    </div>
                </div>
            </li>
            <?php $count++; endwhile;?>
            
        </ul><!--End Accordion Box-->
        
    </div>
</section>
    
<?php endif; ?>

<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>