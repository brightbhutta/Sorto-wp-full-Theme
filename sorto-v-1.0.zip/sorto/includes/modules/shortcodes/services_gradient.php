<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_services' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['services_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   
<!--Four Column FLuid-->
<section class="four-col-fluid">
    <div class="outer clearfix">
        
        <?php while($query->have_posts()): $query->the_post();
			global $post ; 
			$services_meta = _WSH()->get_meta();
		?>
        <!--Icon Column-->
        
        <?php 
			$post_thumbnail_id = get_post_thumbnail_id($post->ID);
			$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
		?> 
        <article class="column icon-left-column <?php echo esc_attr(sorto_set($services_meta, 'color_scheme'));?>" style="background-image:url('<?php echo esc_url($post_thumbnail_url);?>');">
            <div class="overlay"></div>
            
            <div class="inner-box">
                <div class="icon-box"><span class="<?php echo esc_attr(str_replace("icon ","", sorto_set($services_meta, 'fontawesome')));?>"></span></div>
                <div class="content">
                    <h3><?php the_title();?></h3>
                    <div class="text"><?php echo balanceTags(sorto_trim(get_the_content(), $text_limit));?></div>
                    <div class="link"><a href="<?php echo esc_url(sorto_set($services_meta, 'ext_url'));?>" class="read-more"><?php esc_html_e('Find Out More', 'sorto');?> <span class="fa fa-long-arrow-right"></span></a></div>
                </div>
            </div>
        </article>
        <?php endwhile;?>
        
	</div>
</section>

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>