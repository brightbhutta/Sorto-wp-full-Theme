<?php  
   $count = 1;
   $query_args = array('post_type' => 'bunch_services' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   
   if( $cat ) $query_args['services_category'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   

<!--Features Section-->
<section class="features-section">
    <div class="auto-container">
        <!--Section Title-->
        <div class="sec-title text-center">
            <h3><?php echo balanceTags($sub_title);?></h3>
            <h2><?php echo balanceTags($title)?></h2>
            <div class="slices"><span class="slice"></span><span class="slice"></span><span class="slice"></span></div>
        </div>
        
        <!--Bigger Image-->
        <figure class="bigger-image"><img src="<?php echo esc_url(wp_get_attachment_url($image));?>" alt=""></figure>
        
        <div class="row clearfix">
            <?php while($query->have_posts()): $query->the_post();
				global $post ; 
				$services_meta = _WSH()->get_meta();
			?>
            <!--Default Icon Column-->
            <div class="column default-icon-column col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <div class="icon-box"><span class="<?php echo esc_attr(str_replace("icon ","", sorto_set($services_meta, 'fontawesome')));?>"></span></div>
                    <h3><?php the_title();?></h3>
                    <div class="text"><?php echo balanceTags(sorto_trim(get_the_content(), $text_limit));?></div>
                </div>
            </div>
            <?php endwhile;?>
            
        </div>
    </div>
</section>

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>