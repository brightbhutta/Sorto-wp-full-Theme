<?php  
   global $post ;
   $count = 0;
   $query_args = array('post_type' => 'post' , 'showposts' => $num , 'order_by' => $sort , 'order' => $order);
   if( $cat ) $query_args['category_name'] = $cat;
   $query = new WP_Query($query_args) ; 
   
   ob_start() ;?>
   
<?php if($query->have_posts()):  ?>   

<!--Blog Section-->
<section class="blog-section">
    <div class="auto-container">
        <div class="row clearfix">
            <?php while($query->have_posts()): $query->the_post();
				global $post ; 
				$post_meta = _WSH()->get_meta();
			?>
            <!--Blog Post-->
            <div class="column blog-post col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box"><a href="<?php echo esc_url(get_permalink(get_the_id()));?>"><?php the_post_thumbnail('sorto_390x200');?></a><div class="date"><?php echo get_the_date('d M, Y');?></div></figure>
                    <div class="content-box">
                        <h3><a href="<?php echo esc_url(get_permalink(get_the_id()));?>"><?php the_title();?></a></h3>
                        <div class="text"><?php echo balanceTags(sorto_trim(get_the_content(), $text_limit));?></div>
                    </div>
                    <div class="post-info clearfix">
                        <div class="author-info pull-left"><?php esc_html_e('By ', 'sorto');?><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) )); ?>"><?php the_author();?></a></div>
                        <div class="more pull-right"><a href="<?php echo esc_url(get_permalink(get_the_id()));?>" class="read-more"><?php esc_html_e('Read More', 'sorto');?></a></div>
                    </div>
                </div>
            </div>
            <?php endwhile;?>
        </div>
        
        <!-- Styled Pagination -->
        <div class="styled-pagination text-center padd-top-20 padd-bott-20">
            <ul>
                <li><a class="prev" href="#">Prev</a></li>
                <li><a href="#" class="active">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
                <li><a href="#">5</a></li>
                <li><a class="next" href="#">Next</a></li>
            </ul>
        </div>
    </div>
</section>

<?php endif; ?>
<?php 
	wp_reset_postdata();
   $output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>