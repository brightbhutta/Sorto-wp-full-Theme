<?php
ob_start() ;?>

<!--Content Side-->      
<div class="content-side">
    <!--Single Service-->
    <section class="services-single">
                
        <!--Main Image-->
        <figure class="main-image"><img src="<?php echo esc_url(wp_get_attachment_url($image));?>" alt=""></figure>
        
        <h2 class="service-title"><?php echo balanceTags($title);?></h2>
        <!--Default Text Block-->
        <div class="default-text-block">
            <p><?php echo balanceTags($text);?></p>
        </div>
    </section>

</div><!--End Content Side-->

<?php
	$output = ob_get_contents(); 
   ob_end_clean(); 
   return $output ; ?>
   